# Relative path of pattern file to GitPrey
PATH_DB = "pattern/path.db"
FILE_DB = "pattern/file.db"
INFO_DB = "pattern/info.db"

# GitHub account config for searching
USER_NAME = "repoog"
PASSWORD = ""
